#%%
from scipy.sparse import spdiags
import matplotlib.pyplot as plt
import fusion_utils as utils
from tqdm import tqdm 
import numpy as np
import h5py
# import sys
# raise RuntimeError(sys.executable)

# %%
